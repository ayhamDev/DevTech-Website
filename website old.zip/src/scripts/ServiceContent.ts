
// function Ready() {

// }

// function handleHashChange() {

// }
// window.addEventListener("hashchange",handleHashChange)
// handleHashChange()